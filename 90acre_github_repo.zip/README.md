# 90acre Django Project

Full codebase for the 90acre real estate platform.